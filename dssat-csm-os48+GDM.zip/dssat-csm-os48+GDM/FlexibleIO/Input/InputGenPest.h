#ifndef INPUTGP_H
#define INPUTGP_H

struct HeaderDataGenPest
{
    std::string varname;
    int size;
};

void INPUTGENPEST(std::string filePST, std::string PESTID, int FOUND);

#endif